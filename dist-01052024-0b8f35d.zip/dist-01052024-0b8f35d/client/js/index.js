var doohApp = angular.module('doohApp', ['ngRoute']);

// let socket1 = io.connect('http://cdmplite.c1exchange.com:4002', {
//   reconnect: true,
//   withCredentials: true,
// });

let socket = io.connect('http://localhost:3003');

let placeholder = null;

let currentAd = null

doohApp.config(function ($locationProvider, $routeProvider) {
  $locationProvider.html5Mode({
    enabled: true,
    requireBase: false,
  });

  $routeProvider
    .when('/', {
      templateUrl: '/templates/start.html',
      controller: 'InitController',
    })
    .when('/init', {
      templateUrl: '/templates/init.html',
      controller: 'InitController',
    })
    .when('/code/:n', {
      templateUrl: '/templates/init-code.html',
      controller: 'InitController',
    })
    .when('/ads-placeholder', {
      templateUrl: '/templates/ads-placeholder.html',
      controller: 'ShowPlaceholderController',
    })
    .when('/image-ad', {
      templateUrl: '/templates/image-ad.html',
      controller: 'ImageAdController',
    })
    .when('/video-ad', {
      templateUrl: '/templates/video-ad.html',
      controller: 'VideoAdController',
    })
});

doohApp.run(function ($location, $route, $rootScope) {
  let currentAdType = null
  
  socket.on('showCode', (code) => {
    console.log('showCode');
    $location.path('/code/' + code);
    $route.reload();
  });

  socket.on('init', () => {
    console.log('init');
    $location.path('/init');
    $route.reload();
  });

  socket.on('showAd', (ad) => {
    console.log('showAd ', ad);
    $rootScope.ad = ad
    if (ad.adType == 'IMAGE') {
      $location.path('/image-ad/');
    } else {
      $location.path('/video-ad/');
    }
    $rootScope.$apply();
    $route.reload();
  });

  socket.on('showCampaignCounts', (data1) => {

    console.log("Updating data on screen...")
    //const data1 = JSON.parse(data)
    $rootScope.ad.qr.totalCoupons = data1.totalCoupons;
    $rootScope.ad.qr.scannedCoupons = data1.scannedCoupons;
    $rootScope.ad.qr.redeemedCoupons = data1.redeemedCoupons;
    console.log($rootScope.ad?.qr?.scannedCoupons)
    $rootScope.$apply();
  })


  socket.on('token', (payload) => {
    placeholder = payload;
    $location.path('/ads-placeholder');
    $route.reload();
  });

  socket.on('downloaded', (payload) => {
    $location.path('/ads-load');
    $route.reload();
  });
});

doohApp.controller('InitController', function ($scope, $routeParams) {
  let code = $routeParams.n;
  let codes = Array.from(String(code));

  $scope.code = codes;
});

function renderQR(msg) {
  console.log(msg)
  let url = encodeURI(msg)
  console.log(url)
  var qrcode = new QRCode("qrcode", {
    text: url,
    width: 260,
    height: 260,
    colorDark: "#000000",
    colorLight: "#ffffff",
    correctLevel: QRCode.CorrectLevel.L
  });
}


doohApp.controller('ImageAdController', function ($scope, $rootScope, $routeParams, $route) {
  if ($rootScope?.ad?.type == 'PROMOTION') {
    let msg;
    if ($rootScope?.ad?.qr?.type == "WEB") {
      const uuid = $rootScope?.ad?.uuid
      msg = `https://dooh.c1exchange.com:4003/webqr/${uuid}`
    } else if ($rootScope?.ad?.qr?.type == "LINE") {
      const triggerMssg = $rootScope?.ad?.qr?.triggerMessage
      msg = `https://line.me/R/oaMessage/@806evvyj/${triggerMssg}`
    }
    console.log("Message is")
    console.log(msg)
    setTimeout(renderQR.bind(this, msg))
  }
})

doohApp.controller('VideoAdController', function ($scope, $rootScope, $routeParams, $route) {
  if ($rootScope?.ad?.type == 'PROMOTION') {
    let msg;
    if ($rootScope?.ad?.qr?.type == "WEB") {
      const uuid = $rootScope?.ad?.uuid
      msg = `https://dooh.c1exchange.com:4003/webqr/${uuid}`
    } else if ($rootScope?.ad?.qr?.type == "LINE") {
      const triggerMssg = $rootScope?.ad?.qr?.triggerMessage
      msg = `https://line.me/R/oaMessage/@806evvyj/${triggerMssg}`
    }
    setTimeout(renderQR.bind(this, msg))
  }
})

doohApp.controller(
  'ShowPlaceholderController',
  function ($scope, $routeParams) {
    console.log(placeholder);

    let video = document.getElementById('myVideo');
    let img = document.getElementById('myImage');

    if (placeholder) {
      if (placeholder.data.type == 'VIDEO') {
        img.style.display = 'none';
        $scope.video = placeholder.data;
      } else {
        video.style.display = 'none';
        $scope.img = placeholder.data;
      }
    }
  }
);
